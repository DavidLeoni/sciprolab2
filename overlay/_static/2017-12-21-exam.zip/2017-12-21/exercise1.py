

def lopal(S):
    """ Takes a string `S` in input and returns the length of the longest palindrome contained in it.
    """
    raise Exception("TODO IMPLEMENT ME !!!")    