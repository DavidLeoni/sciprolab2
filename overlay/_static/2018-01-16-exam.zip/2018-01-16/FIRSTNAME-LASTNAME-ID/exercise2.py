from math import sqrt

def squares(S):
    """ Given an integer n, return the minimum number of squares that
        need to be summed together to obtain n.
    """
    raise Exception("TODO IMPLEMENT ME !!!")
