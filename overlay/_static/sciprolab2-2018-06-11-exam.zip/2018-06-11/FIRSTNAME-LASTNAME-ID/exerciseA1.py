
# Name    :
# Surname :
# ID      : 

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def loadData(filename):
        raise Exception("TODO IMPLEMENT ME !")

def createMareyPlot(data, chrom):
        raise Exception("TODO IMPLEMENT ME !")
