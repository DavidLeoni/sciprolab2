# Name    :
# Surname :
# ID      :


import pandas as pd
from matplotlib import pyplot as plt



def loadData(filename):
    raise Exception("TODO IMPLEMENT ME !")


def classifyRegions(data, avgDepth, stdDepth):
    raise Exception("TODO IMPLEMENT ME !"


