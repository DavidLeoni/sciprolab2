
def stock(V):
    """ Take a list of positive integers as stock quotes, and return an integer. 
        For more info see exam text and tests.
    """

    raise Exception("TODO IMPLEMENT ME !")
	
